"""
datasets/loaders.py

PyTorch Dataset classes for:
  - ACNE04Dataset   (supervised acne labels)
  - CelebADataset   (weak labels: dark circles, redness)
  - FFHQDataset     (pseudo-labels: texture, redness, dark circles)
  - CombinedSkinDataset  (concatenation + unified label schema)

Label schema (all float32, NaN = missing / masked):
  acne_score
  redness_score
  texture_score
  dark_circle_score
"""

from __future__ import annotations

import os
import random
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
import pandas as pd
import torch
from torch.utils.data import ConcatDataset, Dataset

import albumentations as A
from albumentations.pytorch import ToTensorV2

from preprocessing.face_pipeline import FacePreprocessor
from datasets.pseudo_label_generator import PseudoLabelGenerator

# ── Albumentations augmentation pipelines ─────────────────────────────────────
_TRAIN_AUG = A.Compose([
    A.HorizontalFlip(p=0.5),
    A.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.05, p=0.5),
    A.GaussNoise(var_limit=(5.0, 20.0), p=0.3),
    A.GaussianBlur(blur_limit=(3, 5), p=0.2),
    A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.1, rotate_limit=10, p=0.4),
    A.RandomBrightnessContrast(p=0.3),
    # Normalise + to tensor is handled by FacePreprocessor
])

_ACNE_LABEL_MAP = {0: 0.0, 1: 0.33, 2: 0.66, 3: 1.0}
NAN = float("nan")


# ── Helpers ────────────────────────────────────────────────────────────────────

def _make_label_dict(
    acne: float = NAN,
    redness: float = NAN,
    texture: float = NAN,
    dark_circle: float = NAN,
) -> Dict[str, float]:
    return {
        "acne_score":        acne,
        "redness_score":     redness,
        "texture_score":     texture,
        "dark_circle_score": dark_circle,
    }


def _bgr_augment(bgr: np.ndarray, aug_pipeline: Optional[A.Compose]) -> np.ndarray:
    if aug_pipeline is None:
        return bgr
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    result = aug_pipeline(image=rgb)["image"]
    return cv2.cvtColor(result, cv2.COLOR_RGB2BGR)


# ── Base dataset ───────────────────────────────────────────────────────────────

class _BaseSkinDataset(Dataset):
    """Shared logic for loading, preprocessing, and collating."""

    def __init__(
        self,
        image_paths: List[str],
        labels: List[Dict[str, float]],
        train: bool = True,
        preprocessor: Optional[FacePreprocessor] = None,
    ):
        assert len(image_paths) == len(labels)
        self.image_paths = image_paths
        self.labels = labels
        self.train = train
        self.preprocessor = preprocessor or FacePreprocessor()
        self.augment = _TRAIN_AUG if train else None

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        path = self.image_paths[idx]
        bgr = cv2.imread(path)

        if bgr is None:
            # Return a blank tensor with NaN labels on failed loads
            tensor = torch.zeros(3, 256, 256)
        else:
            bgr = _bgr_augment(bgr, self.augment)
            tensor, _ = self.preprocessor(bgr)
            if tensor is None:
                tensor = torch.zeros(3, 256, 256)

        label = self.labels[idx]
        label_tensors = {
            k: torch.tensor(v, dtype=torch.float32) for k, v in label.items()
        }
        return tensor, label_tensors


# ── ACNE04 Dataset ─────────────────────────────────────────────────────────────

class ACNE04Dataset(_BaseSkinDataset):
    """
    Directory structure expected:
        <root>/
            JPEGImages/<image>.jpg
            ImageSets/  (one .txt per class: 0.txt, 1.txt, 2.txt, 3.txt)
    OR the flat structure used by common ACNE04 releases:
        <root>/
            0/<image>.jpg   (clear)
            1/<image>.jpg   (mild)
            2/<image>.jpg   (moderate)
            3/<image>.jpg   (severe)
    """

    def __init__(self, root: str, train: bool = True, **kwargs):
        root = Path(root)
        image_paths, labels = [], []

        # Support both flat subdirectory layout and ImageSets layout
        for severity, score in _ACNE_LABEL_MAP.items():
            subdir = root / str(severity)
            if subdir.is_dir():
                for ext in ("*.jpg", "*.jpeg", "*.png"):
                    for p in subdir.glob(ext):
                        image_paths.append(str(p))
                        labels.append(_make_label_dict(acne=score))

        if not image_paths:
            raise FileNotFoundError(
                f"No ACNE04 images found in {root}. "
                "Expected subdirectories 0/, 1/, 2/, 3/"
            )

        super().__init__(image_paths, labels, train=train, **kwargs)
        print(f"[ACNE04] Loaded {len(self)} images.")


# ── CelebA Dataset ─────────────────────────────────────────────────────────────

class CelebADataset(_BaseSkinDataset):
    """
    CelebA with weak supervision for redness and dark circles.

    Directory structure:
        <root>/img_align_celeba/<image>.jpg
        <attr_file>: list_attr_celeba.csv  (columns: image_id, 40 attributes)

    Attributes used:
        Rosy_Cheeks  → redness_score  (weak proxy)
        Dark_Circles → dark_circle_score (weak proxy)

    CelebA attribute encoding: -1 = absent, +1 = present.
    We map:  1 → 0.85  (present but noisy)
            -1 → 0.15  (absent  but noisy)
    """

    ATTR_REDNESS     = "Rosy_Cheeks"
    ATTR_DARK_CIRCLE = "Dark_Circles"

    _WEAK_PRESENT = 0.85
    _WEAK_ABSENT  = 0.15

    def __init__(
        self,
        root: str,
        attr_file: str,
        sample_size: int = 15_000,
        train: bool = True,
        seed: int = 42,
        **kwargs,
    ):
        root = Path(root)
        img_dir = root / "img_align_celeba"
        if not img_dir.is_dir():
            img_dir = root   # fallback: images directly in root

        df = pd.read_csv(attr_file)
        # Normalise column names: strip whitespace
        df.columns = [c.strip() for c in df.columns]

        # First column is filename
        filename_col = df.columns[0]

        # Sample
        if sample_size < len(df):
            df = df.sample(n=sample_size, random_state=seed).reset_index(drop=True)

        image_paths, labels = [], []
        for _, row in df.iterrows():
            fname = str(row[filename_col]).strip()
            path = str(img_dir / fname)
            if not os.path.exists(path):
                continue

            redness = (
                self._WEAK_PRESENT
                if int(row.get(self.ATTR_REDNESS, -1)) == 1
                else self._WEAK_ABSENT
            )
            dark = (
                self._WEAK_PRESENT
                if int(row.get(self.ATTR_DARK_CIRCLE, -1)) == 1
                else self._WEAK_ABSENT
            )
            image_paths.append(path)
            labels.append(_make_label_dict(redness=redness, dark_circle=dark))

        super().__init__(image_paths, labels, train=train, **kwargs)
        print(f"[CelebA] Loaded {len(self)} images.")


# ── FFHQ Dataset ───────────────────────────────────────────────────────────────

class FFHQDataset(_BaseSkinDataset):
    """
    FFHQ with pseudo-labels generated from image analysis.

    Directory structure:
        <root>/images/*.png  (or nested as 00000/, 01000/, …)
    """

    def __init__(
        self,
        root: str,
        sample_size: int = 10_000,
        train: bool = True,
        seed: int = 42,
        pseudo_label_cache_dir: str = "data/cache/pseudo_labels",
        **kwargs,
    ):
        root = Path(root)
        all_paths = sorted(
            str(p)
            for p in root.rglob("*")
            if p.suffix.lower() in {".png", ".jpg", ".jpeg"}
        )

        if not all_paths:
            raise FileNotFoundError(f"No images found under {root}")

        random.seed(seed)
        if sample_size < len(all_paths):
            all_paths = random.sample(all_paths, sample_size)

        # Generate / load cached pseudo-labels
        gen = PseudoLabelGenerator(cache_dir=pseudo_label_cache_dir)
        pseudo = gen.generate_for_dataset(all_paths, dataset_name="ffhq")

        image_paths, label_list = [], []
        for p in all_paths:
            pl = pseudo.get(p)
            if pl is None:
                continue
            image_paths.append(p)
            label_list.append(
                _make_label_dict(
                    texture=pl["texture_score"],
                    redness=pl["redness_score"],
                    dark_circle=pl["dark_circle_score"],
                )
            )

        super().__init__(image_paths, label_list, train=train, **kwargs)
        print(f"[FFHQ] Loaded {len(self)} images with pseudo-labels.")


# ── Combined Dataset ───────────────────────────────────────────────────────────

class CombinedSkinDataset(ConcatDataset):
    """
    Concatenates ACNE04 + CelebA + FFHQ into a single multi-task dataset.
    The __getitem__ returns (tensor, label_dict) where missing labels are NaN.
    """

    def __init__(self, datasets: List[Dataset]):
        super().__init__(datasets)

    @staticmethod
    def collate_fn(
        batch: List[Tuple[torch.Tensor, Dict[str, torch.Tensor]]]
    ) -> Tuple[torch.Tensor, Dict[str, torch.Tensor]]:
        """
        Custom collate that handles NaN labels correctly.
        Returns (images, {metric: tensor}) where tensor contains NaN for missing.
        """
        images = torch.stack([b[0] for b in batch])
        keys = batch[0][1].keys()
        label_dict = {
            k: torch.stack([b[1][k] for b in batch]) for k in keys
        }
        return images, label_dict
