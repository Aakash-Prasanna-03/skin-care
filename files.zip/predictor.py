"""
inference/predictor.py

End-to-end inference:
  image path / numpy array
  → FacePreprocessor
  → SkinAnalysisModel
  → SkinReport (four scores + overall score)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Union

import cv2
import numpy as np
import torch

from config import InferenceConfig
from models.skin_model import SkinAnalysisModel
from preprocessing.face_pipeline import FacePreprocessor


@dataclass
class SkinReport:
    """Results returned by the predictor."""

    # ── Individual metric scores (0-1, lower = healthier) ──────────────────
    acne_score:        float
    redness_score:     float
    texture_score:     float
    dark_circle_score: float

    # ── Weighted composite ──────────────────────────────────────────────────
    overall_score: float

    # ── Status ──────────────────────────────────────────────────────────────
    face_detected: bool = True
    error:         Optional[str] = None

    # ── Optional severity labels ────────────────────────────────────────────
    severity: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, object]:
        return {
            "acne_score":        self.acne_score,
            "redness_score":     self.redness_score,
            "texture_score":     self.texture_score,
            "dark_circle_score": self.dark_circle_score,
            "overall_score":     self.overall_score,
            "face_detected":     self.face_detected,
            "severity":          self.severity,
        }

    def __str__(self) -> str:
        lines = [
            "┌─ Skin Analysis Report ──────────────────────┐",
            f"│  Acne severity:     {self.acne_score:.3f}  {self.severity.get('acne',''):>10} │",
            f"│  Redness:           {self.redness_score:.3f}  {self.severity.get('redness',''):>10} │",
            f"│  Texture roughness: {self.texture_score:.3f}  {self.severity.get('texture',''):>10} │",
            f"│  Dark circles:      {self.dark_circle_score:.3f}  {self.severity.get('dark_circle',''):>10} │",
            "├─────────────────────────────────────────────┤",
            f"│  Overall skin score: {self.overall_score:.3f}  {self.severity.get('overall',''):>9} │",
            "└─────────────────────────────────────────────┘",
        ]
        return "\n".join(lines)


def _score_to_severity(score: float) -> str:
    if score < 0.25:
        return "Clear"
    elif score < 0.50:
        return "Mild"
    elif score < 0.75:
        return "Moderate"
    else:
        return "Severe"


class SkinPredictor:
    """
    Loads a trained SkinAnalysisModel and runs inference on single images.

    Parameters
    ----------
    checkpoint_path : str | Path
        Path to the .pth checkpoint file.
    cfg : InferenceConfig, optional
        Inference configuration. Uses defaults if not provided.
    device : str, optional
        Override device ("cuda" | "cpu"). Auto-detected if None.
    """

    def __init__(
        self,
        checkpoint_path: Union[str, Path],
        cfg: Optional[InferenceConfig] = None,
        device: Optional[str] = None,
    ):
        self.cfg = cfg or InferenceConfig()

        if device is not None:
            self.device = torch.device(device)
        else:
            self.device = torch.device(
                "cuda" if torch.cuda.is_available() else "cpu"
            )

        print(f"[SkinPredictor] Device: {self.device}")

        # ── Model ─────────────────────────────────────────────────────────────
        self.model = SkinAnalysisModel(pretrained=False).to(self.device)
        ckpt = torch.load(str(checkpoint_path), map_location=self.device)
        state = ckpt.get("state_dict", ckpt)   # handle bare state_dict too
        self.model.load_state_dict(state)
        self.model.eval()
        print(f"[SkinPredictor] Loaded weights from {checkpoint_path}")

        # ── Face preprocessor ─────────────────────────────────────────────────
        self.preprocessor = FacePreprocessor()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def predict_from_path(self, image_path: Union[str, Path]) -> SkinReport:
        """Run inference on an image file."""
        bgr = cv2.imread(str(image_path))
        if bgr is None:
            return SkinReport(
                acne_score=0, redness_score=0,
                texture_score=0, dark_circle_score=0,
                overall_score=0, face_detected=False,
                error=f"Could not read image: {image_path}",
            )
        return self.predict_from_array(bgr)

    def predict_from_array(self, bgr: np.ndarray) -> SkinReport:
        """Run inference on a BGR numpy array (e.g. from cv2.imread)."""
        tensor, _ = self.preprocessor(bgr)

        if tensor is None:
            return SkinReport(
                acne_score=0, redness_score=0,
                texture_score=0, dark_circle_score=0,
                overall_score=0, face_detected=False,
                error="Face not detected in image.",
            )

        return self._run_model(tensor)

    def predict_from_tensor(self, tensor: torch.Tensor) -> SkinReport:
        """Run inference on a pre-processed tensor (3, 256, 256)."""
        return self._run_model(tensor)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    @torch.no_grad()
    def _run_model(self, tensor: torch.Tensor) -> SkinReport:
        x = tensor.unsqueeze(0).to(self.device)   # (1, 3, 256, 256)

        with torch.cuda.amp.autocast(enabled=self.device.type == "cuda"):
            scores = self.model(x)

        raw = scores.to_cpu_dict()

        acne        = float(raw["acne_score"])
        redness     = float(raw["redness_score"])
        texture     = float(raw["texture_score"])
        dark_circle = float(raw["dark_circle_score"])

        overall = (
            self.cfg.acne_weight        * acne
            + self.cfg.redness_weight   * redness
            + self.cfg.texture_weight   * texture
            + self.cfg.dark_circle_weight * dark_circle
        )

        severity = {
            "acne":        _score_to_severity(acne),
            "redness":     _score_to_severity(redness),
            "texture":     _score_to_severity(texture),
            "dark_circle": _score_to_severity(dark_circle),
            "overall":     _score_to_severity(overall),
        }

        return SkinReport(
            acne_score=acne,
            redness_score=redness,
            texture_score=texture,
            dark_circle_score=dark_circle,
            overall_score=overall,
            face_detected=True,
            severity=severity,
        )
