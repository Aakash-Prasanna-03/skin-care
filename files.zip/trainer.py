"""
training/trainer.py

Multi-task training loop with:
  - Masked loss (NaN labels are ignored)
  - Smooth L1 or MSE loss
  - Per-head loss weighting
  - Mixed-precision training (AMP)
  - Cosine LR schedule with warm-up
  - TensorBoard logging
  - Best-model checkpoint saving
"""

from __future__ import annotations

import math
import os
import random
import time
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from config import TrainConfig, DataConfig, ModelConfig
from datasets.loaders import (
    ACNE04Dataset,
    CelebADataset,
    CombinedSkinDataset,
    FFHQDataset,
)
from models.skin_model import SkinAnalysisModel


# ── Loss with NaN masking ──────────────────────────────────────────────────────

class MaskedRegressionLoss(nn.Module):
    """
    Computes per-sample loss only where the label is valid (not NaN).
    Returns the mean over valid samples; returns 0 if no valid samples.
    """

    def __init__(self, loss_type: str = "smooth_l1", beta: float = 1.0):
        super().__init__()
        if loss_type == "smooth_l1":
            self._fn = nn.SmoothL1Loss(reduction="none", beta=beta)
        elif loss_type == "mse":
            self._fn = nn.MSELoss(reduction="none")
        else:
            raise ValueError(f"Unknown loss_type: {loss_type}")

    def forward(
        self, pred: torch.Tensor, target: torch.Tensor
    ) -> Tuple[torch.Tensor, int]:
        mask = ~torch.isnan(target)
        if mask.sum() == 0:
            return torch.tensor(0.0, device=pred.device, requires_grad=True), 0
        loss = self._fn(pred[mask], target[mask])
        return loss.mean(), int(mask.sum().item())


# ── Trainer ────────────────────────────────────────────────────────────────────

class SkinModelTrainer:

    HEAD_KEYS = ("acne_score", "redness_score", "texture_score", "dark_circle_score")

    def __init__(
        self,
        train_cfg: TrainConfig,
        data_cfg: DataConfig,
        model_cfg: ModelConfig,
    ):
        self.train_cfg = train_cfg
        self.data_cfg = data_cfg
        self.model_cfg = model_cfg

        self._set_seed(train_cfg.seed)

        self.device = torch.device(
            "cuda" if torch.cuda.is_available() else "cpu"
        )
        print(f"[Trainer] Using device: {self.device}")

        # ── Model ─────────────────────────────────────────────────────────────
        self.model = SkinAnalysisModel(
            backbone=model_cfg.backbone,
            pretrained=model_cfg.pretrained,
            shared_fc_dim=model_cfg.shared_fc_dim,
            dropout_rate=model_cfg.dropout_rate,
        ).to(self.device)
        stats = self.model.count_parameters()
        print(f"[Trainer] Parameters — total: {stats['total']:,}, "
              f"trainable: {stats['trainable']:,}")

        # ── Loss ──────────────────────────────────────────────────────────────
        self.criterion = MaskedRegressionLoss(
            loss_type=train_cfg.loss_fn, beta=train_cfg.beta
        )
        self.head_weights = {
            "acne_score":        train_cfg.acne_weight,
            "redness_score":     train_cfg.redness_weight,
            "texture_score":     train_cfg.texture_weight,
            "dark_circle_score": train_cfg.dark_circle_weight,
        }

        # ── Optimiser ─────────────────────────────────────────────────────────
        self.optimizer = torch.optim.AdamW(
            filter(lambda p: p.requires_grad, self.model.parameters()),
            lr=train_cfg.learning_rate,
            weight_decay=train_cfg.weight_decay,
        )

        # ── Datasets & loaders ────────────────────────────────────────────────
        self.train_loader, self.val_loader = self._build_loaders()

        # ── LR Scheduler ──────────────────────────────────────────────────────
        total_steps = len(self.train_loader) * train_cfg.epochs
        self.scheduler = self._build_scheduler(total_steps)

        # ── AMP ───────────────────────────────────────────────────────────────
        self.scaler = torch.cuda.amp.GradScaler(enabled=train_cfg.use_amp and self.device.type == "cuda")

        # ── Logging ───────────────────────────────────────────────────────────
        Path(train_cfg.checkpoint_dir).mkdir(parents=True, exist_ok=True)
        Path(train_cfg.log_dir).mkdir(parents=True, exist_ok=True)
        self.writer = SummaryWriter(log_dir=train_cfg.log_dir)
        self.best_val_loss = float("inf")
        self.global_step = 0

    # ------------------------------------------------------------------
    # Data
    # ------------------------------------------------------------------

    def _build_loaders(self) -> Tuple[DataLoader, DataLoader]:
        datasets = []

        try:
            datasets.append(
                ACNE04Dataset(root=self.data_cfg.acne04_root, train=True)
            )
        except FileNotFoundError as e:
            print(f"[Warning] ACNE04 skipped: {e}")

        try:
            datasets.append(
                CelebADataset(
                    root=self.data_cfg.celeba_root,
                    attr_file=self.data_cfg.celeba_attr_file,
                    sample_size=self.data_cfg.celeba_sample_size,
                    train=True,
                )
            )
        except FileNotFoundError as e:
            print(f"[Warning] CelebA skipped: {e}")

        try:
            datasets.append(
                FFHQDataset(
                    root=self.data_cfg.ffhq_root,
                    sample_size=self.data_cfg.ffhq_sample_size,
                    train=True,
                    pseudo_label_cache_dir=self.data_cfg.pseudo_label_cache_dir,
                )
            )
        except FileNotFoundError as e:
            print(f"[Warning] FFHQ skipped: {e}")

        if not datasets:
            raise RuntimeError("No datasets found! Check your data_cfg paths.")

        combined = CombinedSkinDataset(datasets)

        # Train / val split
        n_val = max(1, int(len(combined) * self.train_cfg.val_split))
        n_train = len(combined) - n_val
        train_ds, val_ds = random_split(
            combined, [n_train, n_val],
            generator=torch.Generator().manual_seed(self.train_cfg.seed),
        )

        train_loader = DataLoader(
            train_ds,
            batch_size=self.train_cfg.batch_size,
            shuffle=True,
            num_workers=self.train_cfg.num_workers,
            collate_fn=CombinedSkinDataset.collate_fn,
            pin_memory=self.device.type == "cuda",
            drop_last=True,
        )
        val_loader = DataLoader(
            val_ds,
            batch_size=self.train_cfg.batch_size,
            shuffle=False,
            num_workers=self.train_cfg.num_workers,
            collate_fn=CombinedSkinDataset.collate_fn,
            pin_memory=self.device.type == "cuda",
        )

        print(f"[Trainer] Train: {n_train} | Val: {n_val}")
        return train_loader, val_loader

    # ------------------------------------------------------------------
    # Scheduler
    # ------------------------------------------------------------------

    def _build_scheduler(self, total_steps: int):
        warmup_steps = len(self.train_loader) * self.train_cfg.warmup_epochs

        def lr_lambda(step: int) -> float:
            if step < warmup_steps:
                return step / max(1, warmup_steps)
            progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
            return 0.5 * (1.0 + math.cos(math.pi * progress))

        return torch.optim.lr_scheduler.LambdaLR(self.optimizer, lr_lambda)

    # ------------------------------------------------------------------
    # Training / Validation steps
    # ------------------------------------------------------------------

    def _compute_total_loss(
        self,
        preds: Dict[str, torch.Tensor],
        labels: Dict[str, torch.Tensor],
    ) -> Tuple[torch.Tensor, Dict[str, float]]:
        total = torch.tensor(0.0, device=self.device)
        per_head = {}
        for key in self.HEAD_KEYS:
            head_loss, n_valid = self.criterion(preds[key], labels[key].to(self.device))
            w = self.head_weights[key]
            total = total + w * head_loss
            per_head[key] = head_loss.item()
        return total, per_head

    def _train_epoch(self, epoch: int) -> float:
        self.model.train()
        total_loss = 0.0
        n_batches = 0

        pbar = tqdm(self.train_loader, desc=f"Epoch {epoch+1} [train]", leave=False)
        for images, labels in pbar:
            images = images.to(self.device, non_blocking=True)

            with torch.cuda.amp.autocast(enabled=self.train_cfg.use_amp and self.device.type == "cuda"):
                scores = self.model(images)
                loss, per_head = self._compute_total_loss(scores.to_dict(), labels)

            self.optimizer.zero_grad()
            self.scaler.scale(loss).backward()
            self.scaler.unscale_(self.optimizer)
            nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.scheduler.step()

            total_loss += loss.item()
            n_batches += 1
            self.global_step += 1

            # TensorBoard
            self.writer.add_scalar("train/loss", loss.item(), self.global_step)
            for k, v in per_head.items():
                self.writer.add_scalar(f"train/{k}", v, self.global_step)

            pbar.set_postfix({"loss": f"{loss.item():.4f}"})

        return total_loss / max(1, n_batches)

    @torch.no_grad()
    def _val_epoch(self, epoch: int) -> float:
        self.model.eval()
        total_loss = 0.0
        n_batches = 0

        for images, labels in tqdm(self.val_loader, desc=f"Epoch {epoch+1} [val]", leave=False):
            images = images.to(self.device, non_blocking=True)

            with torch.cuda.amp.autocast(enabled=self.train_cfg.use_amp and self.device.type == "cuda"):
                scores = self.model(images)
                loss, _ = self._compute_total_loss(scores.to_dict(), labels)

            total_loss += loss.item()
            n_batches += 1

        avg_loss = total_loss / max(1, n_batches)
        self.writer.add_scalar("val/loss", avg_loss, epoch)
        return avg_loss

    # ------------------------------------------------------------------
    # Main train loop
    # ------------------------------------------------------------------

    def train(self):
        print(f"[Trainer] Starting training for {self.train_cfg.epochs} epochs.")

        for epoch in range(self.train_cfg.epochs):
            t0 = time.time()
            train_loss = self._train_epoch(epoch)
            val_loss   = self._val_epoch(epoch)
            elapsed    = time.time() - t0

            lr = self.scheduler.get_last_lr()[0]
            print(
                f"Epoch {epoch+1:3d}/{self.train_cfg.epochs} | "
                f"train_loss={train_loss:.4f} | val_loss={val_loss:.4f} | "
                f"lr={lr:.2e} | {elapsed:.1f}s"
            )
            self.writer.add_scalar("lr", lr, epoch)

            # Save best checkpoint
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
                self._save_checkpoint(epoch, val_loss, best=True)

            # Save periodic checkpoint every 10 epochs
            if (epoch + 1) % 10 == 0:
                self._save_checkpoint(epoch, val_loss, best=False)

        self.writer.close()
        print(f"[Trainer] Done. Best val loss: {self.best_val_loss:.4f}")

    # ------------------------------------------------------------------
    # Checkpoint utils
    # ------------------------------------------------------------------

    def _save_checkpoint(self, epoch: int, val_loss: float, best: bool):
        ckpt = {
            "epoch":      epoch,
            "val_loss":   val_loss,
            "state_dict": self.model.state_dict(),
            "optimizer":  self.optimizer.state_dict(),
        }
        if best:
            path = os.path.join(self.train_cfg.checkpoint_dir, "best_model.pth")
        else:
            path = os.path.join(
                self.train_cfg.checkpoint_dir, f"checkpoint_epoch{epoch+1:03d}.pth"
            )
        torch.save(ckpt, path)
        if best:
            print(f"  ✓ New best model saved → {path}  (val_loss={val_loss:.4f})")

    def load_checkpoint(self, path: str):
        ckpt = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ckpt["state_dict"])
        self.optimizer.load_state_dict(ckpt["optimizer"])
        print(f"[Trainer] Loaded checkpoint from {path} (epoch {ckpt['epoch']+1})")

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    @staticmethod
    def _set_seed(seed: int):
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
