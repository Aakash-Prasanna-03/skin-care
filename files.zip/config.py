"""
config.py — Central configuration for the skin analysis pipeline.
"""

from dataclasses import dataclass, field
from typing import Optional, Tuple
import os


@dataclass
class DataConfig:
    # ── Dataset roots ──────────────────────────────────────────────────────────
    acne04_root: str = "data/ACNE04"
    celeba_root: str = "data/CelebA"
    celeba_attr_file: str = "data/CelebA/list_attr_celeba.csv"
    ffhq_root: str = "data/FFHQ"

    # ── Sampling ───────────────────────────────────────────────────────────────
    celeba_sample_size: int = 15_000       # 10k–20k recommended
    ffhq_sample_size: int = 10_000

    # ── Preprocessing ─────────────────────────────────────────────────────────
    image_size: Tuple[int, int] = (256, 256)
    imagenet_mean: Tuple[float, ...] = (0.485, 0.456, 0.406)
    imagenet_std: Tuple[float, ...] = (0.229, 0.224, 0.225)

    # ── Cache directory for pseudo-labels ─────────────────────────────────────
    pseudo_label_cache_dir: str = "data/cache/pseudo_labels"


@dataclass
class ModelConfig:
    backbone: str = "efficientnet_b2"
    pretrained: bool = True
    shared_fc_dim: int = 256
    dropout_rate: float = 0.3
    num_heads: int = 4                     # acne / redness / texture / dark_circles


@dataclass
class TrainConfig:
    # ── Paths ──────────────────────────────────────────────────────────────────
    checkpoint_dir: str = "checkpoints"
    log_dir: str = "logs"

    # ── Hyper-parameters ──────────────────────────────────────────────────────
    epochs: int = 50
    batch_size: int = 32
    num_workers: int = 4
    learning_rate: float = 3e-4
    weight_decay: float = 1e-4
    lr_scheduler: str = "cosine"          # "cosine" | "step"
    warmup_epochs: int = 3

    # ── Loss ──────────────────────────────────────────────────────────────────
    loss_fn: str = "smooth_l1"            # "smooth_l1" | "mse"
    beta: float = 1.0                     # Smooth L1 beta

    # ── Per-head loss weights ─────────────────────────────────────────────────
    acne_weight: float = 1.0
    redness_weight: float = 1.0
    texture_weight: float = 1.0
    dark_circle_weight: float = 1.0

    # ── Reproducibility ───────────────────────────────────────────────────────
    seed: int = 42
    val_split: float = 0.1

    # ── Mixed precision ───────────────────────────────────────────────────────
    use_amp: bool = True


@dataclass
class InferenceConfig:
    checkpoint_path: str = "checkpoints/best_model.pth"
    device: str = "cuda"                  # "cuda" | "cpu"

    # ── Overall score weights ─────────────────────────────────────────────────
    acne_weight: float = 0.35
    redness_weight: float = 0.25
    texture_weight: float = 0.20
    dark_circle_weight: float = 0.20


@dataclass
class Config:
    data: DataConfig = field(default_factory=DataConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    train: TrainConfig = field(default_factory=TrainConfig)
    inference: InferenceConfig = field(default_factory=InferenceConfig)

    def setup_dirs(self):
        """Create all necessary directories."""
        for d in [
            self.train.checkpoint_dir,
            self.train.log_dir,
            self.data.pseudo_label_cache_dir,
        ]:
            os.makedirs(d, exist_ok=True)


# ── Convenience singleton ──────────────────────────────────────────────────────
cfg = Config()
